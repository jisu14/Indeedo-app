import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { type, workerId, employerId, amount } = body;

    if (!type || !amount) {
      return Response.json(
        { error: "Type and amount are required" },
        { status: 400 },
      );
    }

    // Record payment in database
    const paymentResult = await sql`
      INSERT INTO payments (user_id, user_type, amount, currency, payment_method, status)
      VALUES (${session.user.id}, ${type}, ${amount}, 'INR', 'test', 'paid')
      RETURNING id
    `;

    const paymentId = paymentResult[0].id;

    // Update worker or employer payment status
    if (type === "worker" && workerId) {
      await sql`
        UPDATE workers 
        SET payment_status = 'paid',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ${workerId} AND user_id = ${session.user.id}
      `;
    } else if (type === "employer" && employerId) {
      // Calculate subscription end date (1 year from now)
      const subscriptionEndDate = new Date();
      subscriptionEndDate.setFullYear(subscriptionEndDate.getFullYear() + 1);

      await sql`
        UPDATE employers 
        SET payment_status = 'paid',
            subscription_valid_till = ${subscriptionEndDate.toISOString().split("T")[0]},
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ${employerId} AND user_id = ${session.user.id}
      `;
    }

    // Update user role
    await sql`
      UPDATE auth_users 
      SET role = ${type}
      WHERE id = ${session.user.id}
    `;

    return Response.json({
      success: true,
      paymentId,
      message: "Payment processed successfully",
    });
  } catch (error) {
    console.error("POST /api/payment/test-success error", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
