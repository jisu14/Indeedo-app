import { useState } from "react";
import { Shield, AlertTriangle } from "lucide-react";
import useUser from "@/utils/useUser";

export default function AdminSetupPage() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);
  const { data: user } = useUser();

  const handleCreateAdmin = async () => {
    if (!user) {
      setError("You must be signed in to create an admin account");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/admin/setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to create admin account");
      }

      setSuccess(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4 font-poppins">
            Admin Setup Required
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mb-6 font-inter">
            You need to be signed in to create an admin account.
          </p>
          <a
            href="/account/signin?callbackUrl=/admin/setup"
            className="inline-block px-6 py-3 bg-[#1E3A8A] text-white rounded-lg hover:bg-blue-800 transition-colors font-inter"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 text-center">
          <div className="text-green-500 mb-4">
            <Shield className="w-16 h-16 mx-auto" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4 font-poppins">
            Admin Account Created!
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mb-6 font-inter">
            You now have admin privileges. You can access the admin dashboard
            and manage the platform.
          </p>
          <div className="space-y-3">
            <a
              href="/admin"
              className="block px-6 py-3 bg-[#1E3A8A] text-white rounded-lg hover:bg-blue-800 transition-colors font-inter"
            >
              Go to Admin Dashboard
            </a>
            <a
              href="/"
              className="block px-6 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors font-inter"
            >
              Return to Home
            </a>
          </div>

          <div className="mt-8 p-4 bg-red-50 dark:bg-red-900 border border-red-200 dark:border-red-700 rounded-lg">
            <div className="flex items-center space-x-2 text-red-800 dark:text-red-200">
              <AlertTriangle className="w-5 h-5" />
              <span className="text-sm font-medium font-inter">
                Important Security Note
              </span>
            </div>
            <p className="text-sm text-red-700 dark:text-red-300 mt-2 font-inter">
              For security, you should delete this setup page (/admin/setup)
              after creating your admin account. This route should not be
              accessible in production.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8">
        <div className="text-center mb-8">
          <div className="text-[#1E3A8A] mb-4">
            <Shield className="w-16 h-16 mx-auto" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2 font-poppins">
            Admin Account Setup
          </h1>
          <p className="text-gray-600 dark:text-gray-300 font-inter">
            Create the first admin account for INDEEDO
          </p>
        </div>

        {error && (
          <div className="bg-red-50 dark:bg-red-900 text-red-700 dark:text-red-200 p-4 rounded-lg mb-6 font-inter">
            {error}
          </div>
        )}

        <div className="space-y-4 mb-8">
          <div className="bg-blue-50 dark:bg-blue-900 border border-blue-200 dark:border-blue-700 rounded-lg p-4">
            <h3 className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-2 font-poppins">
              Current User:
            </h3>
            <div className="text-sm text-blue-700 dark:text-blue-300 font-inter">
              <p>
                <strong>Name:</strong> {user.name}
              </p>
              <p>
                <strong>Email:</strong> {user.email}
              </p>
            </div>
          </div>

          <div className="bg-yellow-50 dark:bg-yellow-900 border border-yellow-200 dark:border-yellow-700 rounded-lg p-4">
            <h3 className="text-sm font-medium text-yellow-800 dark:text-yellow-200 mb-2 font-poppins">
              Admin Privileges Include:
            </h3>
            <ul className="text-sm text-yellow-700 dark:text-yellow-300 space-y-1 font-inter">
              <li>• Verify and approve worker profiles</li>
              <li>• Manage employer accounts</li>
              <li>• Edit website content (CMS)</li>
              <li>• View analytics and reports</li>
              <li>• Access payment logs</li>
            </ul>
          </div>
        </div>

        <button
          onClick={handleCreateAdmin}
          disabled={loading}
          className="w-full py-3 bg-[#1E3A8A] text-white rounded-lg font-medium hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-inter"
        >
          {loading ? "Creating Admin Account..." : "Create Admin Account"}
        </button>

        <div className="mt-6 text-center">
          <a
            href="/"
            className="text-sm text-gray-600 dark:text-gray-400 hover:text-[#1E3A8A] dark:hover:text-blue-400 transition-colors font-inter"
          >
            Cancel and return to home
          </a>
        </div>
      </div>
    </div>
  );
}
