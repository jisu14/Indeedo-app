import { useState, useEffect } from "react";
import {
  Home,
  Users,
  Building2,
  BarChart3,
  CreditCard,
  Phone,
  Menu,
  X,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function HomePage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [heroContent, setHeroContent] = useState({
    title: "Dignifying Domestic Work with Digital Trust",
    content:
      "INDEEDO – Inclusive Domestic Employment & Empowerment Digital connects verified domestic workers with families and employers through a secure, trusted platform.",
  });
  const { data: user } = useUser();

  useEffect(() => {
    // Fetch CMS content for hero section
    const fetchHeroContent = async () => {
      try {
        const response = await fetch("/api/cms/hero_title");
        if (response.ok) {
          const data = await response.json();
          if (data.title || data.content) {
            setHeroContent({
              title: data.title || heroContent.title,
              content: data.content || heroContent.content,
            });
          }
        }
      } catch (error) {
        console.error("Failed to fetch hero content:", error);
      }
    };
    fetchHeroContent();
  }, []);

  const navigationCards = [
    {
      icon: Home,
      title: "Hire Domestic Help",
      description: "Connect with verified domestic workers in your area",
      href: "/employer/register",
      color: "bg-blue-50 dark:bg-blue-900 border-blue-200 dark:border-blue-700",
      iconColor: "text-blue-600 dark:text-blue-400",
    },
    {
      icon: Users,
      title: "Join as Worker",
      description:
        "Register as a domestic worker and find dignified employment",
      href: "/worker/register",
      color:
        "bg-green-50 dark:bg-green-900 border-green-200 dark:border-green-700",
      iconColor: "text-green-600 dark:text-green-400",
    },
    {
      icon: Building2,
      title: "CSR & Partnerships",
      description:
        "Partner with us to create inclusive employment opportunities",
      href: "/csr",
      color:
        "bg-purple-50 dark:bg-purple-900 border-purple-200 dark:border-purple-700",
      iconColor: "text-purple-600 dark:text-purple-400",
    },
    {
      icon: BarChart3,
      title: "Dashboard Login",
      description: "Access your personalized dashboard and manage your profile",
      href: user
        ? user.role === "admin"
          ? "/admin"
          : user.role === "worker"
            ? "/worker/dashboard"
            : user.role === "employer"
              ? "/employer/dashboard"
              : "/account/signin"
        : "/account/signin",
      color:
        "bg-orange-50 dark:bg-orange-900 border-orange-200 dark:border-orange-700",
      iconColor: "text-orange-600 dark:text-orange-400",
    },
    {
      icon: CreditCard,
      title: "Subscription Plans",
      description:
        "View membership plans and pricing for workers and employers",
      href: "/pricing",
      color:
        "bg-[#FACC15]/10 dark:bg-yellow-900 border-yellow-200 dark:border-yellow-700",
      iconColor: "text-[#FACC15] dark:text-yellow-400",
    },
    {
      icon: Phone,
      title: "Contact & About",
      description: "Learn more about our mission and get in touch with us",
      href: "/about",
      color: "bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700",
      iconColor: "text-gray-600 dark:text-gray-400",
    },
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-[#121212]">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white dark:bg-[#121212] border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-8 py-3 flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="text-2xl font-bold text-[#1E3A8A] dark:text-white font-poppins">
              INDEEDO
            </div>
            <div className="hidden sm:block text-xs text-gray-600 dark:text-gray-400 font-inter">
              Dignifying Domestic Work
            </div>
          </div>

          {/* Navigation menu - hidden on mobile, shown on larger screens */}
          <div className="hidden sm:flex items-center space-x-6">
            <a
              href="/about"
              className="text-gray-600 dark:text-gray-300 hover:text-[#1E3A8A] dark:hover:text-white transition-colors font-inter"
            >
              About
            </a>
            <a
              href="/pricing"
              className="text-gray-600 dark:text-gray-300 hover:text-[#1E3A8A] dark:hover:text-white transition-colors font-inter"
            >
              Pricing
            </a>
            <a
              href="/csr"
              className="text-gray-600 dark:text-gray-300 hover:text-[#1E3A8A] dark:hover:text-white transition-colors font-inter"
            >
              CSR
            </a>
            {user ? (
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-700 dark:text-gray-300 font-inter">
                  Welcome, {user.name}
                </span>
                <a
                  href="/account/logout"
                  className="px-4 py-2 bg-[#1E3A8A] text-white rounded-lg hover:bg-blue-800 transition-colors font-inter"
                >
                  Sign Out
                </a>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <a
                  href="/account/signin"
                  className="text-gray-600 dark:text-gray-300 hover:text-[#1E3A8A] dark:hover:text-white transition-colors font-inter"
                >
                  Sign In
                </a>
                <a
                  href="/account/signup"
                  className="px-4 py-2 bg-[#1E3A8A] text-white rounded-lg hover:bg-blue-800 transition-colors font-inter"
                >
                  Sign Up
                </a>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            className="sm:hidden p-1 text-gray-600 dark:text-gray-300 hover:text-[#1E3A8A] dark:hover:text-white transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="sm:hidden bg-white dark:bg-[#121212] border-t border-gray-200 dark:border-gray-800 py-4 px-4">
            <div className="flex flex-col space-y-3">
              <a
                href="/about"
                className="text-gray-600 dark:text-gray-300 hover:text-[#1E3A8A] dark:hover:text-white transition-colors font-inter"
              >
                About
              </a>
              <a
                href="/pricing"
                className="text-gray-600 dark:text-gray-300 hover:text-[#1E3A8A] dark:hover:text-white transition-colors font-inter"
              >
                Pricing
              </a>
              <a
                href="/csr"
                className="text-gray-600 dark:text-gray-300 hover:text-[#1E3A8A] dark:hover:text-white transition-colors font-inter"
              >
                CSR
              </a>
              {user ? (
                <div className="flex flex-col space-y-2">
                  <span className="text-sm text-gray-700 dark:text-gray-300 font-inter">
                    Welcome, {user.name}
                  </span>
                  <a
                    href="/account/logout"
                    className="px-4 py-2 bg-[#1E3A8A] text-white rounded-lg hover:bg-blue-800 transition-colors font-inter text-center"
                  >
                    Sign Out
                  </a>
                </div>
              ) : (
                <div className="flex flex-col space-y-2">
                  <a
                    href="/account/signin"
                    className="text-gray-600 dark:text-gray-300 hover:text-[#1E3A8A] dark:hover:text-white transition-colors font-inter"
                  >
                    Sign In
                  </a>
                  <a
                    href="/account/signup"
                    className="px-4 py-2 bg-[#1E3A8A] text-white rounded-lg hover:bg-blue-800 transition-colors font-inter text-center"
                  >
                    Sign Up
                  </a>
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="pt-16 pb-12 sm:pb-20 bg-gray-50 dark:bg-[#1E1E1E] overflow-hidden">
        <div className="max-w-6xl mx-auto px-4 sm:px-8">
          <div className="text-center min-h-[60vh] flex items-center justify-center">
            <div className="space-y-6 sm:space-y-8 pt-4 sm:pt-8">
              {/* Brand section */}
              <div className="space-y-2">
                <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold text-[#1E3A8A] dark:text-white leading-tight font-poppins">
                  INDEEDO
                </h1>
                <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-300 font-inter">
                  Inclusive Domestic Employment & Empowerment Digital
                </p>
              </div>

              {/* Main headline */}
              <h2 className="text-2xl sm:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-gray-100 leading-tight font-poppins max-w-4xl mx-auto">
                {heroContent.title}
              </h2>

              {/* Subtext paragraph */}
              <p className="text-lg sm:text-xl text-gray-600 dark:text-gray-300 leading-relaxed max-w-3xl mx-auto font-inter">
                {heroContent.content}
              </p>

              {/* CTA buttons */}
              <div className="pt-4 sm:pt-6 flex flex-col sm:flex-row gap-4 justify-center items-center">
                <a
                  href="/worker/register"
                  className="px-8 py-3 bg-[#1E3A8A] text-white rounded-lg font-medium hover:bg-blue-800 active:bg-blue-900 transition-colors font-inter"
                >
                  Join as Worker
                </a>
                <a
                  href="/employer/register"
                  className="px-8 py-3 bg-[#FACC15] text-gray-900 rounded-lg font-medium hover:bg-yellow-400 active:bg-yellow-500 transition-colors font-inter"
                >
                  Hire Workers
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Navigation Cards Section */}
      <section className="py-16 sm:py-24 bg-white dark:bg-[#121212]">
        <div className="max-w-6xl mx-auto px-4 sm:px-8">
          {/* Section header */}
          <div className="text-center mb-16 sm:mb-20">
            <h3 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-gray-100 mb-4 font-poppins">
              Get Started
            </h3>
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto font-inter">
              Choose your path to join the INDEEDO community and create
              dignified employment opportunities
            </p>
          </div>

          {/* Navigation cards grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {navigationCards.map((card, index) => (
              <a
                key={index}
                href={card.href}
                className={`${card.color} rounded-xl border p-6 sm:p-8 hover:shadow-lg dark:hover:shadow-none transition-all duration-200 group hover:scale-105`}
              >
                <div className="flex flex-col items-center text-center space-y-4">
                  <div
                    className={`w-12 sm:w-16 h-12 sm:h-16 rounded-lg bg-white dark:bg-gray-700 flex items-center justify-center group-hover:scale-110 transition-transform`}
                  >
                    <card.icon
                      className={`${card.iconColor} w-6 h-6 sm:w-8 sm:h-8`}
                    />
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-lg sm:text-xl font-semibold text-gray-900 dark:text-gray-100 font-poppins">
                      {card.title}
                    </h4>
                    <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400 leading-relaxed font-inter">
                      {card.description}
                    </p>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-12 sm:py-16 bg-gray-900 dark:bg-[#0A0A0A]">
        <div className="max-w-5xl mx-auto px-4 sm:px-8 text-center">
          <p className="text-sm text-gray-400 dark:text-gray-500 mb-8 sm:mb-12 font-inter">
            Trusted by families and workers across India
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 sm:gap-12 opacity-60 items-center justify-items-center">
            <div className="text-gray-400 dark:text-gray-500 font-semibold font-inter">
              Verified Workers
            </div>
            <div className="text-gray-400 dark:text-gray-500 font-semibold font-inter">
              Trusted Families
            </div>
            <div className="text-gray-400 dark:text-gray-500 font-semibold font-inter">
              Secure Platform
            </div>
            <div className="text-gray-400 dark:text-gray-500 font-semibold font-inter">
              Digital Trust
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-50 dark:bg-[#1E1E1E] border-t border-gray-200 dark:border-gray-700 py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Brand */}
            <div className="space-y-4">
              <div className="text-xl font-bold text-[#1E3A8A] dark:text-white font-poppins">
                INDEEDO
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400 font-inter">
                Inclusive Domestic Employment & Empowerment Digital
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400 font-inter">
                "Dignifying Domestic Work with Digital Trust."
              </p>
            </div>

            {/* Quick Links */}
            <div className="space-y-4">
              <h4 className="font-semibold text-gray-900 dark:text-gray-100 font-poppins">
                Quick Links
              </h4>
              <div className="space-y-2">
                <a
                  href="/about"
                  className="block text-sm text-gray-600 dark:text-gray-400 hover:text-[#1E3A8A] dark:hover:text-white transition-colors font-inter"
                >
                  About Us
                </a>
                <a
                  href="/pricing"
                  className="block text-sm text-gray-600 dark:text-gray-400 hover:text-[#1E3A8A] dark:hover:text-white transition-colors font-inter"
                >
                  Pricing
                </a>
                <a
                  href="/csr"
                  className="block text-sm text-gray-600 dark:text-gray-400 hover:text-[#1E3A8A] dark:hover:text-white transition-colors font-inter"
                >
                  CSR & Partnerships
                </a>
                <a
                  href="/contact"
                  className="block text-sm text-gray-600 dark:text-gray-400 hover:text-[#1E3A8A] dark:hover:text-white transition-colors font-inter"
                >
                  Contact
                </a>
              </div>
            </div>

            {/* Contact */}
            <div className="space-y-4">
              <h4 className="font-semibold text-gray-900 dark:text-gray-100 font-poppins">
                Contact Info
              </h4>
              <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400 font-inter">
                <p>Email: contact@indeedo.com</p>
                <p>Phone: +91-9876543210</p>
                <p>Mumbai, Maharashtra, India</p>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-gray-200 dark:border-gray-700 text-center">
            <p className="text-sm text-gray-600 dark:text-gray-400 font-inter">
              © 2025 INDEEDO – Inclusive Domestic Employment & Empowerment
              Digital. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
