import { useState, useEffect } from "react";
import { ArrowLeft, Check, Users, Briefcase } from "lucide-react";

export default function PricingPage() {
  const [pricingContent, setPricingContent] = useState({
    worker:
      "Join our platform for ₹199 per 6 months. Get verified profile, job recommendations, and access to premium employer listings.",
    employer:
      "Access our verified worker database for ₹499 per year. Search, shortlist, and connect with pre-screened domestic help.",
  });

  useEffect(() => {
    // Fetch CMS content for pricing
    const fetchPricingContent = async () => {
      try {
        const [workerResponse, employerResponse] = await Promise.all([
          fetch("/api/cms/pricing_worker"),
          fetch("/api/cms/pricing_employer"),
        ]);

        if (workerResponse.ok) {
          const workerData = await workerResponse.json();
          if (workerData.content) {
            setPricingContent((prev) => ({
              ...prev,
              worker: workerData.content,
            }));
          }
        }

        if (employerResponse.ok) {
          const employerData = await employerResponse.json();
          if (employerData.content) {
            setPricingContent((prev) => ({
              ...prev,
              employer: employerData.content,
            }));
          }
        }
      } catch (error) {
        console.error("Failed to fetch pricing content:", error);
      }
    };

    fetchPricingContent();
  }, []);

  const plans = [
    {
      type: "worker",
      icon: Users,
      title: "Worker Membership",
      price: "₹199",
      duration: "6 months",
      description: pricingContent.worker,
      features: [
        "Create verified profile",
        "Upload ID proof and photos",
        "Access to job opportunities",
        "Direct employer contact",
        "Profile visibility in search",
        "Customer support",
        "Safe and secure platform",
      ],
      buttonText: "Join as Worker",
      buttonLink: "/worker/register",
      popular: false,
      color: "from-green-500 to-green-600",
    },
    {
      type: "employer",
      icon: Briefcase,
      title: "Employer Membership",
      price: "₹499",
      duration: "1 year",
      description: pricingContent.employer,
      features: [
        "Access to verified workers",
        "Advanced search and filters",
        "View worker profiles and photos",
        "Unlimited shortlisting",
        "Direct worker contact",
        "Background verified workers",
        "Priority customer support",
      ],
      buttonText: "Hire Workers",
      buttonLink: "/employer/register",
      popular: true,
      color: "from-blue-500 to-blue-600",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] py-12 px-4">
      {/* Header */}
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <a
            href="/"
            className="inline-flex items-center text-[#1E3A8A] hover:text-blue-800 mb-6"
          >
            <ArrowLeft size={20} className="mr-2" />
            Back to Home
          </a>

          <div className="mb-8">
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white font-poppins mb-4">
              Simple, Transparent Pricing
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto font-inter">
              Choose the plan that works for you. Join thousands of workers and
              employers creating dignified employment opportunities.
            </p>
          </div>

          <div className="text-center">
            <div className="inline-flex items-center bg-[#FACC15]/20 dark:bg-yellow-900/30 rounded-full px-4 py-2">
              <span className="text-sm font-medium text-yellow-800 dark:text-yellow-200 font-inter">
                ✨ No hidden fees • Secure payments • Cancel anytime
              </span>
            </div>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.type}
              className={`relative bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden border-2 transition-all duration-300 hover:shadow-2xl hover:scale-105 ${
                plan.popular
                  ? "border-[#1E3A8A]"
                  : "border-gray-200 dark:border-gray-700"
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10">
                  <span className="bg-[#1E3A8A] text-white px-4 py-1 rounded-full text-sm font-medium font-inter">
                    Most Popular
                  </span>
                </div>
              )}

              {/* Header */}
              <div
                className={`bg-gradient-to-r ${plan.color} text-white p-6 text-center`}
              >
                <plan.icon className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-2xl font-bold font-poppins mb-2">
                  {plan.title}
                </h3>
                <div className="text-4xl font-bold font-poppins">
                  {plan.price}
                  <span className="text-lg opacity-80">/{plan.duration}</span>
                </div>
              </div>

              {/* Body */}
              <div className="p-6">
                <p className="text-gray-600 dark:text-gray-300 mb-6 font-inter">
                  {plan.description}
                </p>

                <div className="mb-8">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-4 font-poppins">
                    What's included:
                  </h4>
                  <ul className="space-y-3">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <Check className="text-green-500 w-5 h-5 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-700 dark:text-gray-300 font-inter">
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                <a
                  href={plan.buttonLink}
                  className={`w-full py-3 px-6 rounded-lg font-medium text-center block transition-all duration-200 font-inter ${
                    plan.popular
                      ? "bg-[#1E3A8A] text-white hover:bg-blue-800 hover:shadow-lg"
                      : "bg-gray-900 dark:bg-gray-700 text-white hover:bg-gray-800 dark:hover:bg-gray-600 hover:shadow-lg"
                  }`}
                >
                  {plan.buttonText}
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="mt-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12 font-poppins">
            Frequently Asked Questions
          </h2>

          <div className="max-w-3xl mx-auto space-y-6">
            {[
              {
                question: "Is there a refund policy?",
                answer:
                  "Yes, we offer a 7-day money-back guarantee if you're not satisfied with our service.",
              },
              {
                question: "How does verification work for workers?",
                answer:
                  "Workers upload ID proof and photos during registration. Our team verifies these documents within 24-48 hours.",
              },
              {
                question: "Can I upgrade or downgrade my plan?",
                answer:
                  "Currently, we offer fixed-term memberships. You can choose a different plan when your current subscription expires.",
              },
              {
                question: "Is my personal information secure?",
                answer:
                  "Yes, we use industry-standard security measures to protect your personal information and payment details.",
              },
              {
                question: "How do I contact customer support?",
                answer:
                  "You can reach us at support@indeedo.com or through the contact form on our website.",
              },
            ].map((faq, index) => (
              <div
                key={index}
                className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md"
              >
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3 font-poppins">
                  {faq.question}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 font-inter">
                  {faq.answer}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-20 text-center">
          <div className="bg-gradient-to-r from-[#1E3A8A] to-blue-700 rounded-2xl p-8 sm:p-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4 font-poppins">
              Ready to Get Started?
            </h2>
            <p className="text-xl text-blue-100 mb-8 font-inter">
              Join the INDEEDO community and create dignified employment
              opportunities today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/worker/register"
                className="px-8 py-3 bg-white text-[#1E3A8A] rounded-lg font-medium hover:bg-gray-100 transition-colors font-inter"
              >
                Join as Worker
              </a>
              <a
                href="/employer/register"
                className="px-8 py-3 bg-[#FACC15] text-gray-900 rounded-lg font-medium hover:bg-yellow-400 transition-colors font-inter"
              >
                Find Workers
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
