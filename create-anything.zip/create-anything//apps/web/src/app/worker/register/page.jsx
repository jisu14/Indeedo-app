import { useState } from "react";
import { Upload, ArrowLeft } from "lucide-react";
import useUpload from "@/utils/useUpload";

export default function WorkerRegisterPage() {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [upload, { loading: uploading }] = useUpload();

  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    city: "",
    gender: "",
    skills: [],
    experience: "",
    idProof: null,
    photo: null,
  });

  const skillOptions = [
    "House Cleaning",
    "Cooking",
    "Baby Care",
    "Elder Care",
    "Laundry",
    "Gardening",
    "Driving",
    "Security",
  ];

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSkillToggle = (skill) => {
    setFormData((prev) => ({
      ...prev,
      skills: prev.skills.includes(skill)
        ? prev.skills.filter((s) => s !== skill)
        : [...prev.skills, skill],
    }));
  };

  const handleFileUpload = async (field, file) => {
    try {
      const result = await upload({
        reactNativeAsset: { file, name: file.name, mimeType: file.type },
      });
      if (result.error) {
        setError(result.error);
      } else {
        setFormData((prev) => ({ ...prev, [field]: result.url }));
      }
    } catch (err) {
      setError("Failed to upload file");
    }
  };

  const validateStep = (stepNumber) => {
    switch (stepNumber) {
      case 1:
        return (
          formData.name && formData.phone && formData.city && formData.gender
        );
      case 2:
        return formData.skills.length > 0 && formData.experience;
      case 3:
        return formData.idProof && formData.photo;
      default:
        return false;
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    setError(null);

    try {
      // First create worker profile
      const response = await fetch("/api/workers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to create profile");
      }

      const worker = await response.json();

      // Redirect to payment
      window.location.href = `/payment?type=worker&workerId=${worker.id}`;
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <a
            href="/"
            className="inline-flex items-center text-[#1E3A8A] hover:text-blue-800 mb-4"
          >
            <ArrowLeft size={20} className="mr-2" />
            Back to Home
          </a>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white font-poppins">
            Join as Worker
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mt-2 font-inter">
            Create your profile and find dignified employment opportunities
          </p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    i <= step
                      ? "bg-[#1E3A8A] text-white"
                      : "bg-gray-200 dark:bg-gray-600 text-gray-600 dark:text-gray-400"
                  }`}
                >
                  {i}
                </div>
                {i < 3 && (
                  <div
                    className={`w-12 h-1 ${i < step ? "bg-[#1E3A8A]" : "bg-gray-200 dark:bg-gray-600"}`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-center mt-2 text-sm text-gray-600 dark:text-gray-400 font-inter">
            Step {step} of 3
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          {error && (
            <div className="bg-red-50 dark:bg-red-900 text-red-700 dark:text-red-200 p-3 rounded-lg mb-6">
              {error}
            </div>
          )}

          {step === 1 && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white font-poppins">
                Personal Information
              </h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 font-inter">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white font-inter"
                    placeholder="Enter your full name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 font-inter">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white font-inter"
                    placeholder="Enter your phone number"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 font-inter">
                    City *
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => handleInputChange("city", e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white font-inter"
                    placeholder="Enter your city"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 font-inter">
                    Gender *
                  </label>
                  <select
                    value={formData.gender}
                    onChange={(e) =>
                      handleInputChange("gender", e.target.value)
                    }
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white font-inter"
                  >
                    <option value="">Select gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <button
                onClick={() => setStep(2)}
                disabled={!validateStep(1)}
                className="w-full py-3 bg-[#1E3A8A] text-white rounded-lg font-medium hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-inter"
              >
                Continue
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white font-poppins">
                Skills & Experience
              </h2>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 font-inter">
                  Select your skills *
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {skillOptions.map((skill) => (
                    <label
                      key={skill}
                      className="flex items-center space-x-2 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={formData.skills.includes(skill)}
                        onChange={() => handleSkillToggle(skill)}
                        className="w-4 h-4 text-[#1E3A8A] border-gray-300 rounded focus:ring-[#1E3A8A]"
                      />
                      <span className="text-sm text-gray-900 dark:text-white font-inter">
                        {skill}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 font-inter">
                  Years of Experience *
                </label>
                <select
                  value={formData.experience}
                  onChange={(e) =>
                    handleInputChange("experience", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white font-inter"
                >
                  <option value="">Select experience</option>
                  <option value="0">No experience</option>
                  <option value="1">1-2 years</option>
                  <option value="3">3-5 years</option>
                  <option value="6">6-10 years</option>
                  <option value="11">10+ years</option>
                </select>
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={() => setStep(1)}
                  className="flex-1 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg font-medium hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors font-inter"
                >
                  Back
                </button>
                <button
                  onClick={() => setStep(3)}
                  disabled={!validateStep(2)}
                  className="flex-1 py-3 bg-[#1E3A8A] text-white rounded-lg font-medium hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-inter"
                >
                  Continue
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white font-poppins">
                Upload Documents
              </h2>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 font-inter">
                    ID Proof (Aadhaar/PAN) *
                  </label>
                  <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={(e) =>
                        handleFileUpload("idProof", e.target.files[0])
                      }
                      className="hidden"
                      id="idProof"
                    />
                    <label htmlFor="idProof" className="cursor-pointer">
                      <Upload className="mx-auto h-12 w-12 text-gray-400" />
                      <p className="mt-2 text-sm text-gray-600 dark:text-gray-400 font-inter">
                        {uploading
                          ? "Uploading..."
                          : formData.idProof
                            ? "ID Proof uploaded"
                            : "Click to upload ID proof"}
                      </p>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 font-inter">
                    Profile Photo *
                  </label>
                  <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) =>
                        handleFileUpload("photo", e.target.files[0])
                      }
                      className="hidden"
                      id="photo"
                    />
                    <label htmlFor="photo" className="cursor-pointer">
                      <Upload className="mx-auto h-12 w-12 text-gray-400" />
                      <p className="mt-2 text-sm text-gray-600 dark:text-gray-400 font-inter">
                        {uploading
                          ? "Uploading..."
                          : formData.photo
                            ? "Photo uploaded"
                            : "Click to upload photo"}
                      </p>
                    </label>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 dark:bg-yellow-900 border border-yellow-200 dark:border-yellow-700 rounded-lg p-4">
                <p className="text-sm text-yellow-800 dark:text-yellow-200 font-inter">
                  <strong>Next Step:</strong> After completing your profile,
                  you'll be redirected to payment (₹199 for 6 months) to
                  activate your account.
                </p>
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={() => setStep(2)}
                  className="flex-1 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg font-medium hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors font-inter"
                >
                  Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={!validateStep(3) || loading}
                  className="flex-1 py-3 bg-[#1E3A8A] text-white rounded-lg font-medium hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-inter"
                >
                  {loading ? "Creating Profile..." : "Complete Registration"}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
