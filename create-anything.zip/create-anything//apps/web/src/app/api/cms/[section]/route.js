import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request, { params }) {
  try {
    const { section } = params;

    const rows = await sql`
      SELECT title, content, last_updated 
      FROM cms_content 
      WHERE section = ${section}
      LIMIT 1
    `;

    if (rows.length === 0) {
      return Response.json({ error: "Content not found" }, { status: 404 });
    }

    return Response.json(rows[0]);
  } catch (error) {
    console.error("GET /api/cms/[section] error", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(request, { params }) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is admin
    const userRows = await sql`
      SELECT role FROM auth_users WHERE id = ${session.user.id} LIMIT 1
    `;

    if (userRows.length === 0 || userRows[0].role !== "admin") {
      return Response.json(
        { error: "Forbidden - Admin access required" },
        { status: 403 },
      );
    }

    const { section } = params;
    const body = await request.json();
    const { title, content } = body;

    if (!title && !content) {
      return Response.json(
        { error: "Title or content is required" },
        { status: 400 },
      );
    }

    // Update or insert CMS content
    const updateRows = await sql`
      UPDATE cms_content 
      SET title = COALESCE(${title}, title),
          content = COALESCE(${content}, content),
          last_updated = CURRENT_TIMESTAMP,
          updated_by = ${session.user.id}
      WHERE section = ${section}
      RETURNING title, content, last_updated
    `;

    if (updateRows.length === 0) {
      // Insert new content if doesn't exist
      const insertRows = await sql`
        INSERT INTO cms_content (section, title, content, updated_by)
        VALUES (${section}, ${title || ""}, ${content || ""}, ${session.user.id})
        RETURNING title, content, last_updated
      `;
      return Response.json(insertRows[0]);
    }

    return Response.json(updateRows[0]);
  } catch (error) {
    console.error("PUT /api/cms/[section] error", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
