import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { name, phone, city, helpType, duration, preferredGender, idProof } =
      body;

    // Validate required fields
    if (
      !name ||
      !phone ||
      !city ||
      !helpType ||
      !duration ||
      !preferredGender
    ) {
      return Response.json(
        { error: "All fields are required" },
        { status: 400 },
      );
    }

    // Check if employer profile already exists for this user
    const existingEmployer = await sql`
      SELECT id FROM employers WHERE user_id = ${session.user.id} LIMIT 1
    `;

    if (existingEmployer.length > 0) {
      return Response.json(
        { error: "Employer profile already exists" },
        { status: 409 },
      );
    }

    // Insert employer profile
    const employerResult = await sql`
      INSERT INTO employers (
        user_id, name, phone, city, help_type, duration, 
        preferred_gender, id_proof_url, payment_status
      ) VALUES (
        ${session.user.id}, ${name}, ${phone}, ${city}, ${helpType}, 
        ${duration}, ${preferredGender}, ${idProof || null}, 'pending'
      )
      RETURNING id, name, phone, city, created_at
    `;

    return Response.json(employerResult[0]);
  } catch (error) {
    console.error("POST /api/employers error", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Check if user is admin
    const userRows = await sql`
      SELECT role FROM auth_users WHERE id = ${session.user.id} LIMIT 1
    `;

    if (userRows.length === 0 || userRows[0].role !== "admin") {
      return Response.json(
        { error: "Forbidden - Admin access required" },
        { status: 403 },
      );
    }

    const { searchParams } = new URL(request.url);
    const city = searchParams.get("city");
    const helpType = searchParams.get("helpType");
    const status = searchParams.get("status");
    const limit = parseInt(searchParams.get("limit") || "20");
    const offset = parseInt(searchParams.get("offset") || "0");

    let query =
      "SELECT e.*, u.name as user_name, u.email FROM employers e JOIN auth_users u ON e.user_id = u.id WHERE 1=1";
    const values = [];

    if (city) {
      query += " AND LOWER(e.city) LIKE LOWER($" + (values.length + 1) + ")";
      values.push(`%${city}%`);
    }

    if (helpType) {
      query +=
        " AND LOWER(e.help_type) LIKE LOWER($" + (values.length + 1) + ")";
      values.push(`%${helpType}%`);
    }

    if (status) {
      query += " AND e.payment_status = $" + (values.length + 1);
      values.push(status);
    }

    query += " ORDER BY e.created_at DESC";
    query +=
      " LIMIT $" + (values.length + 1) + " OFFSET $" + (values.length + 2);
    values.push(limit, offset);

    const employers = await sql(query, values);

    return Response.json(employers);
  } catch (error) {
    console.error("GET /api/employers error", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
