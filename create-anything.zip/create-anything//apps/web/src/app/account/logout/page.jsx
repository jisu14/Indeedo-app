import useAuth from "@/utils/useAuth";

export default function LogoutPage() {
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut({
      callbackUrl: "/",
      redirect: true,
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="mb-6">
            <h2 className="text-3xl font-bold text-[#1E3A8A] dark:text-white font-poppins">
              INDEEDO
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-300 font-inter">
              Inclusive Domestic Employment & Empowerment Digital
            </p>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 font-poppins">
            Sign Out
          </h1>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400 font-inter">
            Are you sure you want to sign out?
          </p>
        </div>

        <div className="mt-8">
          <button
            onClick={handleSignOut}
            className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-[#1E3A8A] hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#1E3A8A] transition-colors font-inter"
          >
            Sign Out
          </button>

          <div className="mt-4 text-center">
            <a
              href="/"
              className="font-medium text-[#1E3A8A] hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 font-inter"
            >
              Cancel and go to home
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
