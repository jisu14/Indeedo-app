import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { name, phone, city, gender, skills, experience, idProof, photo } =
      body;

    // Validate required fields
    if (!name || !phone || !city || !gender || !skills || !experience) {
      return Response.json(
        { error: "All fields are required" },
        { status: 400 },
      );
    }

    // Check if worker profile already exists for this user
    const existingWorker = await sql`
      SELECT id FROM workers WHERE user_id = ${session.user.id} LIMIT 1
    `;

    if (existingWorker.length > 0) {
      return Response.json(
        { error: "Worker profile already exists" },
        { status: 409 },
      );
    }

    // Insert worker profile
    const workerResult = await sql`
      INSERT INTO workers (
        user_id, name, phone, city, gender, skills, experience, 
        id_proof_url, photo_url, payment_status, verified
      ) VALUES (
        ${session.user.id}, ${name}, ${phone}, ${city}, ${gender}, 
        ${JSON.stringify(skills)}, ${parseInt(experience)}, 
        ${idProof || null}, ${photo || null}, 'pending', false
      )
      RETURNING id, name, phone, city, created_at
    `;

    return Response.json(workerResult[0]);
  } catch (error) {
    console.error("POST /api/workers error", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const city = searchParams.get("city");
    const skills = searchParams.get("skills");
    const verified = searchParams.get("verified");
    const limit = parseInt(searchParams.get("limit") || "20");
    const offset = parseInt(searchParams.get("offset") || "0");

    let query =
      "SELECT w.*, u.name as user_name FROM workers w JOIN auth_users u ON w.user_id = u.id WHERE 1=1";
    const values = [];

    if (verified === "true") {
      query +=
        " AND w.verified = true AND w.payment_status = $" + (values.length + 1);
      values.push("paid");
    }

    if (city) {
      query += " AND LOWER(w.city) LIKE LOWER($" + (values.length + 1) + ")";
      values.push(`%${city}%`);
    }

    if (skills) {
      const skillsArray = skills.split(",");
      query += " AND w.skills && $" + (values.length + 1);
      values.push(JSON.stringify(skillsArray));
    }

    query += " ORDER BY w.created_at DESC";
    query +=
      " LIMIT $" + (values.length + 1) + " OFFSET $" + (values.length + 2);
    values.push(limit, offset);

    const workers = await sql(query, values);

    // Parse skills JSON for each worker
    const workersWithParsedSkills = workers.map((worker) => ({
      ...worker,
      skills: Array.isArray(worker.skills)
        ? worker.skills
        : JSON.parse(worker.skills || "[]"),
    }));

    return Response.json(workersWithParsedSkills);
  } catch (error) {
    console.error("GET /api/workers error", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
