import { useState, useEffect } from "react";
import {
  Search,
  Filter,
  Heart,
  Phone,
  MapPin,
  Star,
  Calendar,
  ArrowLeft,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function EmployerDashboardPage() {
  const [workers, setWorkers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchCity, setSearchCity] = useState("");
  const [searchSkills, setSearchSkills] = useState("");
  const [shortlisted, setShortlisted] = useState(new Set());
  const [error, setError] = useState(null);
  const { data: user } = useUser();

  const skillOptions = [
    "House Cleaning",
    "Cooking",
    "Baby Care",
    "Elder Care",
    "Laundry",
    "Gardening",
    "Driving",
    "Security",
  ];

  useEffect(() => {
    if (user && user.role !== "employer") {
      setError("Access denied. Only employers can view this page.");
      return;
    }
    fetchWorkers();
    fetchShortlisted();
  }, [user]);

  const fetchWorkers = async (city = "", skills = "") => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (city) params.append("city", city);
      if (skills) params.append("skills", skills);
      params.append("verified", "true"); // Only show verified workers

      const response = await fetch(`/api/workers?${params}`);
      if (!response.ok) {
        throw new Error("Failed to fetch workers");
      }
      const data = await response.json();
      setWorkers(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchShortlisted = async () => {
    try {
      const response = await fetch("/api/shortlists");
      if (response.ok) {
        const data = await response.json();
        setShortlisted(new Set(data.map((item) => item.worker_id)));
      }
    } catch (err) {
      console.error("Failed to fetch shortlisted workers:", err);
    }
  };

  const handleSearch = () => {
    fetchWorkers(searchCity, searchSkills);
  };

  const handleShortlist = async (workerId) => {
    try {
      if (shortlisted.has(workerId)) {
        // Remove from shortlist
        const response = await fetch(`/api/shortlists/${workerId}`, {
          method: "DELETE",
        });
        if (response.ok) {
          setShortlisted((prev) => {
            const newSet = new Set(prev);
            newSet.delete(workerId);
            return newSet;
          });
        }
      } else {
        // Add to shortlist
        const response = await fetch("/api/shortlists", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ workerId }),
        });
        if (response.ok) {
          setShortlisted((prev) => new Set([...prev, workerId]));
        }
      }
    } catch (err) {
      console.error("Failed to update shortlist:", err);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Loading...
          </h1>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600 dark:text-red-400 mb-4">
            {error}
          </h1>
          <a href="/" className="text-[#1E3A8A] hover:text-blue-800">
            Return to Home
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E]">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <a
                href="/"
                className="flex items-center text-[#1E3A8A] hover:text-blue-800"
              >
                <ArrowLeft size={20} className="mr-2" />
                <span className="font-medium font-inter">Home</span>
              </a>
              <div className="h-6 border-l border-gray-300 dark:border-gray-600"></div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white font-poppins">
                Employer Dashboard
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600 dark:text-gray-300 font-inter">
                Welcome, {user.name}
              </span>
              <a
                href="/account/logout"
                className="px-3 py-1 text-sm border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors font-inter"
              >
                Sign Out
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filter Section */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 mb-8">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 font-poppins">
            Find Workers
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 font-inter">
                City
              </label>
              <input
                type="text"
                value={searchCity}
                onChange={(e) => setSearchCity(e.target.value)}
                placeholder="Enter city name"
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white font-inter"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 font-inter">
                Skills
              </label>
              <select
                value={searchSkills}
                onChange={(e) => setSearchSkills(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white font-inter"
              >
                <option value="">All skills</option>
                {skillOptions.map((skill) => (
                  <option key={skill} value={skill}>
                    {skill}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-end">
              <button
                onClick={handleSearch}
                disabled={loading}
                className="w-full px-4 py-2 bg-[#1E3A8A] text-white rounded-md hover:bg-blue-800 disabled:opacity-50 transition-colors flex items-center justify-center space-x-2 font-inter"
              >
                <Search className="w-4 h-4" />
                <span>{loading ? "Searching..." : "Search"}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Workers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            <div className="col-span-full text-center py-12">
              <div className="text-gray-600 dark:text-gray-400 font-inter">
                Loading workers...
              </div>
            </div>
          ) : workers.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <div className="text-gray-600 dark:text-gray-400 font-inter">
                No verified workers found. Try adjusting your search criteria.
              </div>
            </div>
          ) : (
            workers.map((worker) => (
              <div
                key={worker.id}
                className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden hover:shadow-md transition-shadow"
              >
                {/* Worker Photo */}
                <div className="relative h-48 bg-gray-200 dark:bg-gray-700">
                  {worker.photo_url ? (
                    <img
                      src={worker.photo_url}
                      alt={worker.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-400">
                      <div className="text-center">
                        <div className="text-4xl mb-2">👤</div>
                        <div className="text-sm font-inter">No photo</div>
                      </div>
                    </div>
                  )}

                  {/* Verification Badge */}
                  {worker.verified && (
                    <div className="absolute top-3 left-3 bg-green-500 text-white px-2 py-1 rounded-full text-xs font-medium flex items-center space-x-1">
                      <Star className="w-3 h-3" />
                      <span>Verified</span>
                    </div>
                  )}

                  {/* Shortlist Button */}
                  <button
                    onClick={() => handleShortlist(worker.id)}
                    className={`absolute top-3 right-3 p-2 rounded-full transition-colors ${
                      shortlisted.has(worker.id)
                        ? "bg-red-500 text-white"
                        : "bg-white text-gray-600 hover:bg-gray-100"
                    }`}
                  >
                    <Heart
                      className="w-4 h-4"
                      fill={
                        shortlisted.has(worker.id) ? "currentColor" : "none"
                      }
                    />
                  </button>
                </div>

                <div className="p-4">
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2 font-poppins">
                    {worker.name}
                  </h3>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                      <MapPin className="w-4 h-4" />
                      <span className="font-inter">{worker.city}</span>
                    </div>

                    <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                      <Calendar className="w-4 h-4" />
                      <span className="font-inter">
                        {worker.experience} years experience
                      </span>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 font-inter">
                      Skills:
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {worker.skills.slice(0, 3).map((skill, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-md text-xs font-inter"
                        >
                          {skill}
                        </span>
                      ))}
                      {worker.skills.length > 3 && (
                        <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-md text-xs font-inter">
                          +{worker.skills.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <button className="flex-1 px-3 py-2 bg-[#1E3A8A] text-white rounded-md hover:bg-blue-800 transition-colors text-sm flex items-center justify-center space-x-1 font-inter">
                      <Phone className="w-4 h-4" />
                      <span>Contact</span>
                    </button>

                    <button className="px-3 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-sm font-inter">
                      View Profile
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Stats Section */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 text-center">
            <div className="text-2xl font-bold text-[#1E3A8A] dark:text-blue-400 mb-2 font-poppins">
              {workers.length}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400 font-inter">
              Available Workers
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 text-center">
            <div className="text-2xl font-bold text-green-600 dark:text-green-400 mb-2 font-poppins">
              {shortlisted.size}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400 font-inter">
              Shortlisted
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 text-center">
            <div className="text-2xl font-bold text-[#FACC15] dark:text-yellow-400 mb-2 font-poppins">
              Active
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400 font-inter">
              Membership Status
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
