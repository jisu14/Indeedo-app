import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Update user role to admin
    const result = await sql`
      UPDATE auth_users 
      SET role = 'admin'
      WHERE id = ${session.user.id}
      RETURNING id, name, email, role
    `;

    if (result.length === 0) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }

    return Response.json({
      success: true,
      user: result[0],
      message: "Admin account created successfully",
    });
  } catch (error) {
    console.error("POST /api/admin/setup error", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
