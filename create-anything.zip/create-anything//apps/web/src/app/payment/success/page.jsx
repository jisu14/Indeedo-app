import { useState, useEffect } from "react";
import { CheckCircle, ArrowRight, Home } from "lucide-react";

export default function PaymentSuccessPage() {
  const [type, setType] = useState(null);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const urlParams = new URLSearchParams(window.location.search);
      setType(urlParams.get("type"));
    }
  }, []);

  const nextSteps = {
    worker: {
      title: "Worker Registration Complete!",
      description:
        "Your profile has been created successfully. Our team will verify your documents within 24-48 hours.",
      actions: [
        { label: "View Worker Dashboard", href: "/worker/dashboard" },
        { label: "Back to Home", href: "/" },
      ],
    },
    employer: {
      title: "Employer Registration Complete!",
      description:
        "Welcome to INDEEDO! You can now search and connect with verified domestic workers.",
      actions: [
        { label: "Browse Workers", href: "/employer/dashboard" },
        { label: "Back to Home", href: "/" },
      ],
    },
  };

  const currentStep = nextSteps[type] || nextSteps.worker;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 text-center">
          <div className="mb-6">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white font-poppins">
              Payment Successful!
            </h1>
          </div>

          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-3 font-poppins">
              {currentStep.title}
            </h2>
            <p className="text-gray-600 dark:text-gray-300 font-inter">
              {currentStep.description}
            </p>
          </div>

          <div className="space-y-3">
            {currentStep.actions.map((action, index) => (
              <a
                key={index}
                href={action.href}
                className={`w-full py-3 px-4 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2 font-inter ${
                  index === 0
                    ? "bg-[#1E3A8A] text-white hover:bg-blue-800"
                    : "border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                }`}
              >
                {index === 0 ? (
                  <ArrowRight className="w-4 h-4" />
                ) : (
                  <Home className="w-4 h-4" />
                )}
                <span>{action.label}</span>
              </a>
            ))}
          </div>

          <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
            <p className="text-sm text-gray-600 dark:text-gray-400 font-inter">
              Need help? Contact us at{" "}
              <a
                href="mailto:support@indeedo.com"
                className="text-[#1E3A8A] hover:text-blue-800"
              >
                support@indeedo.com
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
