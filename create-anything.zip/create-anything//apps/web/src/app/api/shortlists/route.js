import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const { workerId } = body;

    if (!workerId) {
      return Response.json({ error: "Worker ID is required" }, { status: 400 });
    }

    // Get employer ID for current user
    const employerRows = await sql`
      SELECT id FROM employers WHERE user_id = ${session.user.id} LIMIT 1
    `;

    if (employerRows.length === 0) {
      return Response.json(
        { error: "Employer profile not found" },
        { status: 404 },
      );
    }

    const employerId = employerRows[0].id;

    // Check if already shortlisted
    const existingShortlist = await sql`
      SELECT id FROM shortlists 
      WHERE employer_id = ${employerId} AND worker_id = ${workerId} 
      LIMIT 1
    `;

    if (existingShortlist.length > 0) {
      return Response.json(
        { error: "Worker already shortlisted" },
        { status: 409 },
      );
    }

    // Add to shortlist
    const result = await sql`
      INSERT INTO shortlists (employer_id, worker_id)
      VALUES (${employerId}, ${workerId})
      RETURNING id, employer_id, worker_id, created_at
    `;

    return Response.json(result[0]);
  } catch (error) {
    console.error("POST /api/shortlists error", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get employer ID for current user
    const employerRows = await sql`
      SELECT id FROM employers WHERE user_id = ${session.user.id} LIMIT 1
    `;

    if (employerRows.length === 0) {
      return Response.json(
        { error: "Employer profile not found" },
        { status: 404 },
      );
    }

    const employerId = employerRows[0].id;

    // Get shortlisted workers
    const shortlists = await sql`
      SELECT 
        s.id,
        s.worker_id,
        s.created_at,
        w.name as worker_name,
        w.city,
        w.skills,
        w.experience,
        w.photo_url,
        w.verified
      FROM shortlists s
      JOIN workers w ON s.worker_id = w.id
      WHERE s.employer_id = ${employerId}
      ORDER BY s.created_at DESC
    `;

    // Parse skills JSON for each worker
    const shortlistsWithParsedSkills = shortlists.map((shortlist) => ({
      ...shortlist,
      skills: Array.isArray(shortlist.skills)
        ? shortlist.skills
        : JSON.parse(shortlist.skills || "[]"),
    }));

    return Response.json(shortlistsWithParsedSkills);
  } catch (error) {
    console.error("GET /api/shortlists error", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
