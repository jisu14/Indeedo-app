import { useState, useEffect } from "react";
import {
  User,
  MapPin,
  Star,
  Clock,
  Phone,
  Mail,
  Camera,
  ArrowLeft,
} from "lucide-react";
import useUser from "@/utils/useUser";

export default function WorkerDashboardPage() {
  const [worker, setWorker] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { data: user } = useUser();

  useEffect(() => {
    if (user && user.role !== "worker") {
      setError("Access denied. Only workers can view this page.");
      return;
    }
    fetchWorkerProfile();
  }, [user]);

  const fetchWorkerProfile = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/workers/profile");
      if (!response.ok) {
        if (response.status === 404) {
          setError(
            "Worker profile not found. Please complete your registration.",
          );
        } else {
          throw new Error("Failed to fetch worker profile");
        }
        return;
      }
      const data = await response.json();
      setWorker(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "paid":
        return "text-green-600 dark:text-green-400";
      case "pending":
        return "text-yellow-600 dark:text-yellow-400";
      case "failed":
        return "text-red-600 dark:text-red-400";
      default:
        return "text-gray-600 dark:text-gray-400";
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case "paid":
        return "Active";
      case "pending":
        return "Payment Pending";
      case "failed":
        return "Payment Failed";
      default:
        return "Unknown";
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Loading...
          </h1>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] flex items-center justify-center">
        <div className="text-center max-w-md">
          <h1 className="text-2xl font-bold text-red-600 dark:text-red-400 mb-4">
            {error}
          </h1>
          <div className="space-y-3">
            {error.includes("profile not found") && (
              <a
                href="/worker/register"
                className="block px-4 py-2 bg-[#1E3A8A] text-white rounded-lg hover:bg-blue-800 transition-colors font-inter"
              >
                Complete Registration
              </a>
            )}
            <a href="/" className="block text-[#1E3A8A] hover:text-blue-800">
              Return to Home
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E]">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <a
                href="/"
                className="flex items-center text-[#1E3A8A] hover:text-blue-800"
              >
                <ArrowLeft size={20} className="mr-2" />
                <span className="font-medium font-inter">Home</span>
              </a>
              <div className="h-6 border-l border-gray-300 dark:border-gray-600"></div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white font-poppins">
                Worker Dashboard
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600 dark:text-gray-300 font-inter">
                Welcome, {user.name}
              </span>
              <a
                href="/account/logout"
                className="px-3 py-1 text-sm border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors font-inter"
              >
                Sign Out
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading ? (
          <div className="text-center py-12">
            <div className="text-gray-600 dark:text-gray-400 font-inter">
              Loading profile...
            </div>
          </div>
        ) : worker ? (
          <div className="space-y-8">
            {/* Profile Overview */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
              <div className="bg-gradient-to-r from-[#1E3A8A] to-blue-700 px-6 py-8">
                <div className="flex items-center space-x-6">
                  {/* Profile Photo */}
                  <div className="relative">
                    <div className="w-24 h-24 rounded-full bg-white flex items-center justify-center overflow-hidden">
                      {worker.photo_url ? (
                        <img
                          src={worker.photo_url}
                          alt={worker.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <User className="w-12 h-12 text-gray-400" />
                      )}
                    </div>
                    {worker.verified && (
                      <div className="absolute -bottom-1 -right-1 bg-green-500 text-white p-1.5 rounded-full">
                        <Star className="w-4 h-4" />
                      </div>
                    )}
                  </div>

                  {/* Profile Info */}
                  <div className="flex-1 text-white">
                    <h2 className="text-2xl font-bold font-poppins mb-2">
                      {worker.name}
                    </h2>
                    <div className="flex items-center space-x-4 text-blue-100">
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-4 h-4" />
                        <span className="font-inter">{worker.city}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span className="font-inter">
                          {worker.experience} years experience
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Status */}
                  <div className="text-right">
                    <div className="bg-white/20 rounded-lg px-3 py-2 backdrop-blur-sm">
                      <div className="text-white font-medium font-inter text-sm">
                        {worker.verified
                          ? "Verified Profile"
                          : "Pending Verification"}
                      </div>
                      <div
                        className={`text-sm font-inter ${getStatusColor(worker.payment_status)}`}
                      >
                        {getStatusText(worker.payment_status)}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <button className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-shadow text-left">
                <User className="w-8 h-8 text-[#1E3A8A] mb-3" />
                <h3 className="font-semibold text-gray-900 dark:text-white mb-1 font-poppins">
                  Edit Profile
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 font-inter">
                  Update your skills and information
                </p>
              </button>

              <button className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-shadow text-left">
                <Camera className="w-8 h-8 text-green-600 mb-3" />
                <h3 className="font-semibold text-gray-900 dark:text-white mb-1 font-poppins">
                  Update Photos
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 font-inter">
                  Upload new profile and ID photos
                </p>
              </button>

              <button className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-shadow text-left">
                <Phone className="w-8 h-8 text-purple-600 mb-3" />
                <h3 className="font-semibold text-gray-900 dark:text-white mb-1 font-poppins">
                  Contact Support
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 font-inter">
                  Get help with your account
                </p>
              </button>
            </div>

            {/* Profile Details */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Skills & Experience */}
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 font-poppins">
                  Skills & Experience
                </h3>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300 font-inter">
                      Skills
                    </label>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {worker.skills.map((skill, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full text-sm font-inter"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300 font-inter">
                      Experience Level
                    </label>
                    <div className="mt-1 text-sm text-gray-900 dark:text-white font-inter">
                      {worker.experience} years
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300 font-inter">
                      Gender
                    </label>
                    <div className="mt-1 text-sm text-gray-900 dark:text-white capitalize font-inter">
                      {worker.gender}
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 font-poppins">
                  Contact Information
                </h3>

                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Phone className="w-5 h-5 text-gray-400" />
                    <div>
                      <label className="text-sm font-medium text-gray-700 dark:text-gray-300 font-inter">
                        Phone Number
                      </label>
                      <div className="text-sm text-gray-900 dark:text-white font-inter">
                        {worker.phone}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Mail className="w-5 h-5 text-gray-400" />
                    <div>
                      <label className="text-sm font-medium text-gray-700 dark:text-gray-300 font-inter">
                        Email Address
                      </label>
                      <div className="text-sm text-gray-900 dark:text-white font-inter">
                        {user.email}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <MapPin className="w-5 h-5 text-gray-400" />
                    <div>
                      <label className="text-sm font-medium text-gray-700 dark:text-gray-300 font-inter">
                        Location
                      </label>
                      <div className="text-sm text-gray-900 dark:text-white font-inter">
                        {worker.city}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Status Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 text-center">
                <div className="text-2xl font-bold text-[#1E3A8A] dark:text-blue-400 mb-2 font-poppins">
                  {worker.verified ? "Verified" : "Pending"}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400 font-inter">
                  Profile Status
                </div>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 text-center">
                <div
                  className={`text-2xl font-bold mb-2 font-poppins ${getStatusColor(worker.payment_status)}`}
                >
                  {getStatusText(worker.payment_status)}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400 font-inter">
                  Membership Status
                </div>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 text-center">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400 mb-2 font-poppins">
                  Active
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400 font-inter">
                  Account Status
                </div>
              </div>
            </div>

            {/* Action Needed */}
            {(!worker.verified || worker.payment_status !== "paid") && (
              <div className="bg-yellow-50 dark:bg-yellow-900 border border-yellow-200 dark:border-yellow-700 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-yellow-800 dark:text-yellow-200 mb-2 font-poppins">
                  Action Required
                </h3>
                <div className="space-y-2">
                  {worker.payment_status !== "paid" && (
                    <p className="text-sm text-yellow-700 dark:text-yellow-300 font-inter">
                      • Complete your payment to activate your membership
                    </p>
                  )}
                  {!worker.verified && (
                    <p className="text-sm text-yellow-700 dark:text-yellow-300 font-inter">
                      • Your profile is under review. Our team will verify your
                      documents within 24-48 hours.
                    </p>
                  )}
                </div>
                {worker.payment_status !== "paid" && (
                  <div className="mt-4">
                    <a
                      href={`/payment?type=worker&workerId=${worker.id}`}
                      className="inline-block px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 transition-colors font-inter"
                    >
                      Complete Payment
                    </a>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="text-gray-600 dark:text-gray-400 font-inter">
              Worker profile not found.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
