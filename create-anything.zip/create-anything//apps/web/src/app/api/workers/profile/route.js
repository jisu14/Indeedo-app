import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get worker profile for current user
    const workerRows = await sql`
      SELECT w.*, u.name as user_name, u.email
      FROM workers w 
      JOIN auth_users u ON w.user_id = u.id 
      WHERE w.user_id = ${session.user.id} 
      LIMIT 1
    `;

    if (workerRows.length === 0) {
      return Response.json(
        { error: "Worker profile not found" },
        { status: 404 },
      );
    }

    const worker = workerRows[0];

    // Parse skills JSON
    const workerWithParsedSkills = {
      ...worker,
      skills: Array.isArray(worker.skills)
        ? worker.skills
        : JSON.parse(worker.skills || "[]"),
    };

    return Response.json(workerWithParsedSkills);
  } catch (error) {
    console.error("GET /api/workers/profile error", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const {
      name,
      phone,
      city,
      gender,
      skills,
      experience,
      photo_url,
      id_proof_url,
    } = body;

    // Get worker profile for current user
    const workerRows = await sql`
      SELECT id FROM workers WHERE user_id = ${session.user.id} LIMIT 1
    `;

    if (workerRows.length === 0) {
      return Response.json(
        { error: "Worker profile not found" },
        { status: 404 },
      );
    }

    const workerId = workerRows[0].id;

    // Build update query dynamically
    const updateFields = [];
    const values = [];
    let paramCount = 0;

    if (name) {
      updateFields.push(`name = $${++paramCount}`);
      values.push(name);
    }
    if (phone) {
      updateFields.push(`phone = $${++paramCount}`);
      values.push(phone);
    }
    if (city) {
      updateFields.push(`city = $${++paramCount}`);
      values.push(city);
    }
    if (gender) {
      updateFields.push(`gender = $${++paramCount}`);
      values.push(gender);
    }
    if (skills && Array.isArray(skills)) {
      updateFields.push(`skills = $${++paramCount}`);
      values.push(JSON.stringify(skills));
    }
    if (experience !== undefined) {
      updateFields.push(`experience = $${++paramCount}`);
      values.push(parseInt(experience));
    }
    if (photo_url !== undefined) {
      updateFields.push(`photo_url = $${++paramCount}`);
      values.push(photo_url);
    }
    if (id_proof_url !== undefined) {
      updateFields.push(`id_proof_url = $${++paramCount}`);
      values.push(id_proof_url);
    }

    if (updateFields.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    // Add updated_at
    updateFields.push(`updated_at = CURRENT_TIMESTAMP`);

    const query = `
      UPDATE workers 
      SET ${updateFields.join(", ")} 
      WHERE id = $${++paramCount}
      RETURNING *
    `;
    values.push(workerId);

    const result = await sql(query, values);

    if (result.length === 0) {
      return Response.json(
        { error: "Failed to update worker profile" },
        { status: 500 },
      );
    }

    const updatedWorker = result[0];

    // Parse skills JSON for response
    const workerWithParsedSkills = {
      ...updatedWorker,
      skills: Array.isArray(updatedWorker.skills)
        ? updatedWorker.skills
        : JSON.parse(updatedWorker.skills || "[]"),
    };

    return Response.json(workerWithParsedSkills);
  } catch (error) {
    console.error("PUT /api/workers/profile error", error);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
