import { useState, useEffect } from "react";
import { ArrowLeft, CreditCard, Shield, Check } from "lucide-react";

export default function PaymentPage() {
  const [type, setType] = useState(null);
  const [workerId, setWorkerId] = useState(null);
  const [employerId, setEmployerId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Get query parameters on client side
    if (typeof window !== "undefined") {
      const urlParams = new URLSearchParams(window.location.search);
      setType(urlParams.get("type"));
      setWorkerId(urlParams.get("workerId"));
      setEmployerId(urlParams.get("employerId"));
    }
  }, []);

  const planDetails = {
    worker: {
      title: "Worker Membership",
      price: "₹199",
      duration: "6 months",
      amount: 19900, // in paise
      features: [
        "Verified profile creation",
        "Access to job opportunities",
        "Direct employer contact",
        "Profile visibility boost",
        "Customer support",
      ],
    },
    employer: {
      title: "Employer Membership",
      price: "₹499",
      duration: "1 year",
      amount: 49900, // in paise
      features: [
        "Access to verified workers",
        "Advanced search filters",
        "Unlimited shortlisting",
        "Direct worker contact",
        "Priority support",
      ],
    },
  };

  const currentPlan = planDetails[type];

  useEffect(() => {
    if (!type || !currentPlan) {
      setError("Invalid payment request");
    }
  }, [type, currentPlan]);

  const handlePayment = async () => {
    setLoading(true);
    setError(null);

    try {
      // Create payment session
      const response = await fetch("/api/payment/create-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: type,
          workerId: workerId,
          employerId: employerId,
          amount: currentPlan.amount,
          currency: "INR",
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to create payment session");
      }

      const { sessionUrl } = await response.json();

      // Redirect to Stripe Checkout
      window.location.href = sessionUrl;
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleTestPayment = async () => {
    setLoading(true);
    setError(null);

    try {
      // For testing - mark payment as successful
      const response = await fetch("/api/payment/test-success", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: type,
          workerId: workerId,
          employerId: employerId,
          amount: currentPlan.amount,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Payment processing failed");
      }

      // Redirect to success page
      window.location.href = `/payment/success?type=${type}`;
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  if (!currentPlan) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600 dark:text-red-400 mb-4">
            Invalid Payment Request
          </h1>
          <a href="/" className="text-[#1E3A8A] hover:text-blue-800">
            Return to Home
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#1E1E1E] py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <a
            href="/"
            className="inline-flex items-center text-[#1E3A8A] hover:text-blue-800 mb-4"
          >
            <ArrowLeft size={20} className="mr-2" />
            Back to Home
          </a>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white font-poppins">
            Complete Your Payment
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mt-2 font-inter">
            Secure your membership and start your journey with INDEEDO
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
          {/* Plan Details */}
          <div className="bg-gradient-to-r from-[#1E3A8A] to-blue-700 text-white p-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold font-poppins">
                {currentPlan.title}
              </h2>
              <div className="mt-4">
                <span className="text-4xl font-bold">{currentPlan.price}</span>
                <span className="text-lg opacity-80">
                  /{currentPlan.duration}
                </span>
              </div>
            </div>
          </div>

          <div className="p-6">
            {error && (
              <div className="bg-red-50 dark:bg-red-900 text-red-700 dark:text-red-200 p-4 rounded-lg mb-6">
                {error}
              </div>
            )}

            {/* Features */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 font-poppins">
                What's included:
              </h3>
              <div className="space-y-3">
                {currentPlan.features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <Check className="text-green-500 w-5 h-5 flex-shrink-0" />
                    <span className="text-gray-700 dark:text-gray-300 font-inter">
                      {feature}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Security Info */}
            <div className="bg-blue-50 dark:bg-blue-900 border border-blue-200 dark:border-blue-700 rounded-lg p-4 mb-6">
              <div className="flex items-center space-x-2">
                <Shield className="text-blue-600 dark:text-blue-400 w-5 h-5" />
                <span className="text-blue-800 dark:text-blue-200 font-medium font-inter">
                  Secure Payment
                </span>
              </div>
              <p className="text-sm text-blue-700 dark:text-blue-300 mt-2 font-inter">
                Your payment is processed securely through Stripe. We don't
                store your card details.
              </p>
            </div>

            {/* Payment Button */}
            <div className="space-y-4">
              <button
                onClick={handlePayment}
                disabled={loading}
                className="w-full py-4 bg-[#1E3A8A] text-white rounded-lg font-medium text-lg hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2 font-inter"
              >
                <CreditCard className="w-5 h-5" />
                <span>
                  {loading
                    ? "Processing..."
                    : `Pay ${currentPlan.price} with Stripe`}
                </span>
              </button>

              {/* Test Payment Button - For development */}
              <button
                onClick={handleTestPayment}
                disabled={loading}
                className="w-full py-3 border-2 border-[#FACC15] text-[#1E3A8A] bg-[#FACC15] rounded-lg font-medium hover:bg-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-inter"
              >
                {loading ? "Processing..." : `Test Payment (Development Only)`}
              </button>
            </div>

            {/* Terms */}
            <div className="text-center mt-6">
              <p className="text-sm text-gray-600 dark:text-gray-400 font-inter">
                By proceeding, you agree to our{" "}
                <a href="/terms" className="text-[#1E3A8A] hover:text-blue-800">
                  Terms of Service
                </a>{" "}
                and{" "}
                <a
                  href="/privacy"
                  className="text-[#1E3A8A] hover:text-blue-800"
                >
                  Privacy Policy
                </a>
              </p>
            </div>
          </div>
        </div>

        {/* Support */}
        <div className="text-center mt-8">
          <p className="text-sm text-gray-600 dark:text-gray-400 font-inter">
            Need help? Contact us at{" "}
            <a
              href="mailto:support@indeedo.com"
              className="text-[#1E3A8A] hover:text-blue-800"
            >
              support@indeedo.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
